package com.vikram.task2.main;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.vikram.data.Input;
import com.vikram.task2.service.ISeatingService;
import com.vikram.task2.service.SeatingService;

public class Program {
	/*
	 * author Vikram Guraya
	 * */

	public static void main(String[] args) {
		System.out.println("Enter the number of candidates");
		int n=Input.readInt();
		ISeatingService service=new SeatingService();
		List<List<String>> list=service.findSeatRows(n);
		for(List<String> map:list) {
			map.forEach((v)->{
				System.out.print(v.charAt(0)+"  ");
			});
			System.out.println();
		}
	}

}
