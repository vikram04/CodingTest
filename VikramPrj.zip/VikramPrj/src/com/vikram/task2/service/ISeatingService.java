package com.vikram.task2.service;

import java.util.List;
import java.util.Map;

public interface ISeatingService {
	/*
	 * author Vikram Guraya
	 * */

	List<List<String>> findSeatRows(int n);
}
