package com.vikram.task2.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SeatingService implements ISeatingService{
	/*
	 * author Vikram Guraya
	 * */

	public List<List<String>> findSeatRows(int n){
		List<List<String>> rows=new ArrayList<>();
		List<String> map1=new ArrayList<>();
		List<String> map2=new ArrayList<>();
		int i;
		for(i=1;i<=n/2;i++) {
			map1.add(i%3==1?"Physics":i%3==2?"Chemistry":"Maths");
		}
		i++;
		for(i=i;i<=n;i++) {
			map2.add(i%3==1?"Physics":i%3==2?"Chemistry":"Maths");
		}
		if(n%9==0)
			map2.add("Physics");
		rows.add(map1);
		rows.add(map2);
		return rows;
	}
}
