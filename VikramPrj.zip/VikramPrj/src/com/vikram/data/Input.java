package com.vikram.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.vikram.task1.model.SensorData;

public class Input {
	/*
	 * author Vikram Guraya
	 * */

	static Scanner in;
	static {
		in=new Scanner(System.in);
	}
	
	public static String readLine() {
		return in.nextLine();
	}

	public static double readDouble() {
		double d1=in.nextDouble();
		in.nextLine();
		return d1;
	}

	public static int readInt() {
		int d1=in.nextInt();
		in.nextLine();
		return d1;
	}

	public List<SensorData> getInputList(){
		System.out.println("Provide input data......blank when ended");
		List<SensorData> list=new ArrayList<>();
		while(true) {
			String line=readLine();
			if(line.length()==0)
				break;
			SensorData data=new SensorData(line);
			list.add(data);
		}
		return list;
	}
}
