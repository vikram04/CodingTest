/**
 * 
 */
package com.vikram.task1.service;

import java.util.List;
import java.util.Map;

import com.vikram.task1.model.SensorData;

/**
 * @author Vikram Guraya
 *
 */
public interface ItemperatureService {

	 Map<String,Double> findOutputs(List<SensorData> data, double duration);

}