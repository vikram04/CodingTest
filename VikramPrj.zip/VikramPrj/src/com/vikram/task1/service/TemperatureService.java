package com.vikram.task1.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.vikram.task1.model.SensorData;

public class TemperatureService implements ItemperatureService {

	@Override
	public Map<String,Double> findOutputs(List<SensorData> data, double duration) {
		//List<OutputData> list=new ArrayList<>();
		Map<String,Double> result=new HashMap<>();
		Map<String,Integer> resultCount=new HashMap<>();
		int iduration=(int)(duration*1000);
		data.forEach(d1->{
			long irange=d1.getTimeStamp()/iduration;
			String range=irange*1000+"-"+(irange*1000+999);
			double avg=0;
			if(resultCount.get(range)==null) {
				resultCount.put(range, 1);
				avg=d1.getTemperature();
				result.put(range, avg);
			}else {
				avg=result.get(range);
				int count=resultCount.get(range);
				avg=avg*count+d1.getTemperature();
				count++;
				avg/=count;
				resultCount.put(range, count);
				result.put(range, avg);
			}
		});
		return result;
	}

}
