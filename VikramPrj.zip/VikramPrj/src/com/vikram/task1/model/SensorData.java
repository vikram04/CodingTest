package com.vikram.task1.model;

public class SensorData {
/*
 * Created By Vikram Guraya
 * */
	private int sensorId;
	private long timeStamp;
	private int temperature;
	public int getSensorId() {
		return sensorId;
	}
	public void setSensorId(int sensorId) {
		this.sensorId = sensorId;
	}
	public long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public int getTemperature() {
		return temperature;
	}
	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}
	public SensorData(int sensorId, long timeStamp, int temperature) {
		super();
		this.sensorId = sensorId;
		this.timeStamp = timeStamp;
		this.temperature = temperature;
	}
	public SensorData(String input) {
		String arr[]=input.split(",");
		sensorId=Integer.parseInt(arr[0].trim());
		timeStamp=Long.parseLong(arr[1].trim());
		temperature=Integer.parseInt(arr[2].trim());
	}
	public SensorData() {
	}
	
}
