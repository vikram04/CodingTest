package com.vikram.task1.main;

import java.util.List;
import java.util.Map;

import com.vikram.data.Input;
import com.vikram.task1.model.SensorData;
import com.vikram.task1.service.ItemperatureService;
import com.vikram.task1.service.TemperatureService;

public class Program {
/*
 * author Vikram Guraya
 * */
	public static void main(String[] args) {
		Input data=new Input();
		List<SensorData> inputList=data.getInputList();
		ItemperatureService service=new TemperatureService();
		System.out.println("Enter the duration(in seconds) for average");
		double duration=Input.readDouble();
		Map<String,Double> map = service.findOutputs(inputList, duration);
		map.forEach((k,v)->{
			System.out.println(k+": "+v);
		});
	}

}
